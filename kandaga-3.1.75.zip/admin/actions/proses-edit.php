<?php
require_once __DIR__ . '/../../config/bootstrap.php';
require_once __DIR__ . '/../includes/manuscript.php';
kandagaSaveManuscript(true);
