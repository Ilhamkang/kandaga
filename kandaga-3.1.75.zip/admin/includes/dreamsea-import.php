<?php
// DREAMSEA ingestion: strict staging, explicit moderation, and normalized manuscript fields.
require_once __DIR__ . '/catalog-import.php';
require_once __DIR__ . '/upload.php';

function dsReady() {
    if (!kiReady()) return false;
    $names = ['katalog_structure','katalog_identifiers','katalog_location_history'];
    $r = kiQuery('SELECT table_name FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name IN (?,?,?)', $names)->get_result();
    return $r->num_rows === count($names);
}
function dsBatches() { return kiBatches(KI_ENGINE_WEB); }
function dsFindBatch($hash) { return kiFindBatch($hash, KI_ENGINE_WEB); }
function dsInsertBatch($filename, $hash, $label, $mappingJson) { return kiInsertBatch(KI_ENGINE_WEB, $filename, $hash, $label, null, $mappingJson); }
function dsFields() {
    return [
        'msid', 'ds_id', 'record_type', 'parent_msid', 'unit_label', 'unit_order', 'structure_notes',
        'Judul', 'Kode_Inventaris', 'Lokasi_Target', 'Bahasa_List', 'Aksara_List', 'Alas_Tulis_List',
        'Deskripsi_Fisik', 'Deskripsi_Isi', 'Riwayat_Naskah', 'Kata_Kunci', 'Penyedia_Akses',
        'URL_Web', 'URL_Repositori', 'IIIF_Manifest', 'URL_PDF', 'url_gambar_eksternal',
        'Identifier_Scheme', 'Identifier_Value', 'Identifier_Source',
        'Location_Kind', 'Location_Place', 'Location_District', 'Location_Province',
        'Location_Country', 'Location_Period', 'Location_Certainty', 'Location_Source', 'Bibliografi_ID'
    ];
}
function dsTermAliases() { return kiTermAliases(); }
function dsNormalTerm($value) {
    $term = trim((string)$value);
    if ($term === '') return '';
    $alias = dsTermAliases()[kiNorm($term)] ?? null;
    return $alias ?? $term;
}
function dsSplit($value) {
    $out = [];
    foreach (preg_split('/[;,|]/u', (string)$value) as $part) {
        $part = dsNormalTerm($part);
        if ($part !== '' && !in_array($part, $out, true)) $out[] = $part;
    }
    return $out;
}
function dsCode($value) {
    return strtoupper(preg_replace('/[^0-9A-Za-z]+/', '', (string)$value));
}
// DREAMSEA "City (Province)" often arrives as "Indramayu (Jawa Barat)".
// Keep that legacy shape readable, but write kabupaten/kota and provinsi to separate columns.
function dsCityProvince($value) {
    $value = trim((string)$value);
    if ($value === '') return ['district' => '', 'province' => '', 'combined' => false];
    if (preg_match('/^(.+?)\s*\(([^()]+)\)\s*$/u', $value, $m)) {
        return ['district' => trim($m[1]), 'province' => trim($m[2]), 'combined' => true];
    }
    return ['district' => '', 'province' => $value, 'combined' => false];
}
function dsAppendPlace($place, $part) {
    $place = trim((string)$place);
    $part = trim((string)$part);
    if ($part === '' || $place === '') return $place !== '' ? $place : $part;
    if (mb_stripos($place, $part, 0, 'UTF-8') !== false) return $place;
    return $place . ', ' . $part;
}
// Normalize the four location markers used by katalog_location_history:
// place_name (desa/kecamatan/koleksi), district (kabupaten/kota), province, country.
function dsLocationParts($raw) {
    $place = trim((string)($raw['Location_Place'] ?? ''));
    $district = trim((string)($raw['Location_District'] ?? ''));
    $province = trim((string)($raw['Location_Province'] ?? ''));
    $country = trim((string)($raw['Location_Country'] ?? ''));
    $city = dsCityProvince($province);
    if ($city['combined']) {
        // An old CSV may have put kecamatan in Location_District; keep it with the village.
        $place = dsAppendPlace($place, $district);
        $district = $city['district'];
        $province = $city['province'];
    } else {
        $legacy = dsCityProvince($district);
        if ($legacy['combined']) {
            $district = $legacy['district'];
            $province = $legacy['province'] !== '' ? $legacy['province'] : $province;
        }
    }
    if ($district !== '' && $place !== '') {
        $parts = preg_split('/\s*,\s*/u', $place);
        $last = end($parts);
        if (kiNorm($last) === kiNorm($district)) array_pop($parts);
        $place = implode(', ', $parts);
        $place = preg_replace('/[\s\-–—]*' . preg_quote($district, '/') . '\s*$/iu', '', $place);
        $place = trim($place, " \t\n\r\0\x0B,-–—");
    }
    return ['place' => $place, 'district' => $district, 'province' => $province, 'country' => $country];
}
function dsIdentity($raw) {
    $msid = trim((string)($raw['msid'] ?? ''));
    $ds = trim((string)($raw['ds_id'] ?? ''));
    if ($msid === '' && $ds === '') {
        // Importer Web juga menerima CSV scraping lain yang memakai pasangan
        // Identifier_Scheme/Identifier_Value sebagai identitas utama.
        $scheme = trim((string)($raw['Identifier_Scheme'] ?? ''));
        $value = trim((string)($raw['Identifier_Value'] ?? ''));
        if ($scheme === '' || $value === '') throw new InvalidArgumentException('Baris harus memiliki msid, ds_id, atau Identifier_Scheme/Identifier_Value.');
        $primary = ['scheme' => mb_substr($scheme, 0, 64), 'value' => mb_substr($value, 0, 255)];
        $key = hash('sha256', $primary['scheme'] . '|' . kiNorm($primary['value']));
        return ['msid' => '', 'ds_id' => '', 'ds_scheme' => '', 'source_key' => $key, 'primary' => $primary];
    }
    if (preg_match('/^\d{1,6}$/', $msid)) $msid = 'MS' . str_pad($msid, 6, '0', STR_PAD_LEFT);
    $dsScheme = '';
    if ($ds !== '' && preg_match('/^DS\s*\d{4}\s*\d{5}$/i', $ds)) $dsScheme = 'dreamsea-ds';
    elseif ($ds !== '') {
        if (mb_strlen($ds) > 255) throw new InvalidArgumentException('ds_id maksimal 255 karakter.');
        $dsScheme = 'web-source';
    }
    if ($ds === '' && preg_match('/\b(DS\s*\d{4}\s*\d{5})\b/i', (string)($raw['Kode_Inventaris'] ?? ''), $m)) { $ds = $m[1]; $dsScheme = 'dreamsea-ds'; }
    if ($ds === '' && preg_match('/\b(DS\s*\d{4}\s*\d{5})\b/i', (string)($raw['URL_Repositori'] ?? ''), $m)) { $ds = $m[1]; $dsScheme = 'dreamsea-ds'; }
    $primary = $msid !== ''
        ? ['scheme' => 'dreamsea-msid', 'value' => $msid]
        : ['scheme' => $dsScheme, 'value' => kiNorm($ds)];
    $key = hash('sha256', $primary['scheme'] . '|' . kiNorm($primary['value']));
    return ['msid' => $msid, 'ds_id' => $ds, 'ds_scheme' => $dsScheme, 'source_key' => $key, 'primary' => $primary];
}
function dsSourceLabel($raw) {
    return trim((string)($raw['Penyedia_Akses'] ?? '')) ?: 'Web';
}
function dsDraft($raw) {
    foreach (dsFields() as $field) if (!array_key_exists($field, $raw)) $raw[$field] = '';
    $title = trim((string)$raw['Judul']);
    if ($title === '') throw new InvalidArgumentException('Judul wajib diisi.');
    if (mb_strlen($title) > 255) throw new InvalidArgumentException('Judul maksimal 255 karakter.');
    $identity = dsIdentity($raw);
    $sourceLabel = dsSourceLabel($raw);
    $inventory = trim((string)$raw['Kode_Inventaris']);
    if (mb_strlen($inventory) > 255) throw new InvalidArgumentException('Kode inventaris maksimal 255 karakter.');
    $certainty = trim((string)$raw['Location_Certainty']);
    if ($certainty !== '' && !in_array($certainty, ['pasti', 'kemungkinan', 'dugaan', 'belum_diketahui'], true)) throw new InvalidArgumentException('Location_Certainty tidak dikenal.');
    $kind = trim((string)$raw['Location_Kind']) ?: 'asal';
    if (!in_array($kind, ['asal', 'ditemukan', 'sebelumnya'], true)) throw new InvalidArgumentException('Location_Kind tidak dikenal.');
    $order = filter_var($raw['unit_order'], FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    $recordType = trim((string)$raw['record_type']) ?: 'induk';
    if (!in_array($recordType, ['induk', 'unit'], true)) throw new InvalidArgumentException('record_type harus induk atau unit.');
    $fields = [
        'judul' => $title, 'kode_inventaris' => $inventory, 'id_lokasi' => 0,
        'deskripsi_fisik' => trim((string)$raw['Deskripsi_Fisik']),
        'deskripsi_isi' => trim((string)$raw['Deskripsi_Isi']),
        'riwayat_naskah' => trim((string)$raw['Riwayat_Naskah']),
        'kata_kunci' => trim((string)$raw['Kata_Kunci']),
        'penyedia_akses' => $sourceLabel,
        'url_web' => trim((string)$raw['URL_Web']), 'url_repositori' => trim((string)$raw['URL_Repositori']),
        'iiif_manifest' => trim((string)$raw['IIIF_Manifest']), 'url_pdf' => trim((string)$raw['URL_PDF']),
        'url_gambar_eksternal' => trim((string)$raw['url_gambar_eksternal'])
    ];
    foreach (['url_web' => 'URL_Web', 'url_repositori' => 'URL_Repositori', 'iiif_manifest' => 'IIIF_Manifest', 'url_pdf' => 'URL_PDF', 'url_gambar_eksternal' => 'url_gambar_eksternal'] as $key => $label) {
        $fields[$key] = kandagaValidateExternalUrl($fields[$key], $label);
    }
    $identifiers = [];
    $extraScheme = trim((string)$raw['Identifier_Scheme']);
    $extraValue = trim((string)$raw['Identifier_Value']);
    $extraIsPrimary = kiNorm($identity['primary']['scheme']) === kiNorm($extraScheme) && kiNorm($identity['primary']['value']) === kiNorm($extraValue);
    if ($extraScheme !== '' && $extraValue !== '' && !$extraIsPrimary) {
        $identifiers[] = ['scheme' => mb_substr($extraScheme, 0, 64), 'value' => mb_substr($extraValue, 0, 255), 'source' => mb_substr((string)$raw['Identifier_Source'] ?: $sourceLabel, 0, 255), 'primary' => false];
    }
    $candidates = [$identity['primary']];
    if ($identity['ds_scheme'] === 'dreamsea-ds' && $identity['primary']['scheme'] !== 'dreamsea-ds') $candidates[] = ['scheme' => 'dreamsea-ds', 'value' => kiNorm($identity['ds_id'])];
    foreach ($candidates as $candidate) {
        if ($candidate['value'] === '') continue;
        $identifiers[] = ['scheme' => $candidate['scheme'], 'value' => $candidate['value'], 'source' => $sourceLabel, 'primary' => $candidate === $identity['primary']];
    }
    $shelfmark = '';
    if (strpos($inventory, ';') !== false) $shelfmark = trim(substr($inventory, strpos($inventory, ';') + 1));
    if ($shelfmark !== '') $identifiers[] = ['scheme' => 'shelfmark', 'value' => mb_substr($shelfmark, 0, 255), 'source' => $sourceLabel, 'primary' => false];
    $bib = [];
    foreach (preg_split('/[,;|]/u', (string)$raw['Bibliografi_ID']) as $value) {
        $value = filter_var(trim($value), FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        if ($value) $bib[] = $value;
    }
    $location = dsLocationParts($raw);
    $locationHistory = [];
    if ($location['place'] !== '' || trim((string)$raw['Lokasi_Target']) !== '') {
        $locationHistory[] = [
            'kind' => $kind, 'place' => mb_substr($location['place'] ?: (string)$raw['Lokasi_Target'], 0, 255),
            'district' => mb_substr($location['district'], 0, 150), 'province' => mb_substr($location['province'], 0, 150),
            'country' => mb_substr($location['country'], 0, 150), 'period' => mb_substr((string)$raw['Location_Period'], 0, 150),
            'certainty' => $certainty ?: 'belum_diketahui', 'source' => trim((string)$raw['Location_Source']) ?: $sourceLabel, 'sort_order' => 1
        ];
    }
    return [
        'source' => array_merge($raw, $identity, ['location' => $location]),
        'fields' => $fields,
        'relations' => ['bahasa' => dsSplit($raw['Bahasa_List']), 'aksara' => dsSplit($raw['Aksara_List']), 'alas_tulis' => dsSplit($raw['Alas_Tulis_List'])],
        'structure' => ['record_type' => $recordType, 'parent_msid' => trim((string)$raw['parent_msid']), 'unit_label' => mb_substr((string)$raw['unit_label'], 0, 100), 'unit_order' => $order ?: null, 'notes' => (string)$raw['structure_notes']],
        'identifiers' => $identifiers, 'location_history' => $locationHistory, 'bibliografi' => array_values(array_unique($bib))
    ];
}
function dsKey($draft) { return $draft['source']['source_key']; }
function dsSuggestions($draft, $masters) {
    $out = ['lokasi' => null, 'bahasa' => [], 'aksara' => [], 'alas_tulis' => [], 'parent' => null, 'unresolved' => []];
    $target = (string)($draft['source']['Lokasi_Target'] ?? '');
    foreach ($masters['lokasi'] as $item) if (kiNorm($item['name']) === kiNorm($target)) { $out['lokasi'] = (int)$item['id']; break; }
    if ($out['lokasi'] === null && $target !== '') $out['unresolved'][] = ['group' => 'lokasi', 'term' => $target];
    foreach (['bahasa', 'aksara', 'alas_tulis'] as $group) {
        foreach ($draft['relations'][$group] as $term) {
            $found = null;
            foreach ($masters[$group] as $item) if (kiNorm($item['name']) === kiNorm($term)) { $found = (int)$item['id']; break; }
            if ($found === null) $out['unresolved'][] = ['group' => $group, 'term' => $term]; else $out[$group][] = $found;
        }
    }
    return $out;
}
function dsCandidates($draft) {
    // Satu kandidat per entri katalog: semua sinyal yang cocok digabung dalam satu alasan.
    $found = [];
    $add = function ($id, $judul, $kodeInventaris, $reason, $score) use (&$found) {
        $id = (int)$id;
        if (!isset($found[$id])) {
            $found[$id] = ['id' => $id, 'judul' => (string)$judul, 'kode_inventaris' => (string)$kodeInventaris, 'reasons' => [], 'score' => 0];
        }
        if (!in_array($reason, $found[$id]['reasons'], true)) $found[$id]['reasons'][] = $reason;
        $found[$id]['score'] = max($found[$id]['score'], (int)$score);
    };
    $identity = $draft['source'];
    $schemes = [
        $identity['primary']['scheme'] => [$identity['primary']['value']],
        'dreamsea-msid' => [$identity['msid']],
        $identity['ds_scheme'] => [kiNorm($identity['ds_id'])]
    ];
    foreach ($schemes as $scheme => $values) {
        foreach ($values as $value) {
            if ($value === '') continue;
            $rows = kiQuery('SELECT i.id_naskah, k.judul, k.kode_inventaris FROM katalog_identifiers i LEFT JOIN katalog k ON k.id=i.id_naskah WHERE i.scheme=? AND i.identifier_value=?', [$scheme, $value])->get_result()->fetch_all(MYSQLI_ASSOC);
            foreach ($rows as $row) $add($row['id_naskah'], $row['judul'], $row['kode_inventaris'], 'Identitas ' . $scheme . ' sama', 100);
        }
    }
    $linked = kiLinked($draft['source']['source_key']);
    if ($linked) $add($linked['katalog_id'], $linked['judul'], '', 'Sumber sudah ditautkan', 100);
    $codes = kiCodes($draft['fields']['kode_inventaris']);
    $title = kiCode($draft['fields']['judul']);
    $rows = kiQuery('SELECT k.id, k.judul, k.kode_inventaris FROM katalog k')->get_result();
    while ($row = $rows->fetch_assoc()) {
        if ($codes && array_intersect($codes, kiCodes($row['kode_inventaris']))) $add($row['id'], $row['judul'], $row['kode_inventaris'], 'Kode inventaris sama/varian', 80);
        $other = kiCode($row['judul']);
        if ($title !== '' && $title === $other && mb_strlen($title) >= 8) $add($row['id'], $row['judul'], $row['kode_inventaris'], 'Judul sama', 60);
    }
    $out = [];
    foreach ($found as $item) {
        $item['reason'] = implode('; ', $item['reasons']);
        unset($item['reasons']);
        $out[] = $item;
    }
    usort($out, fn($a, $b) => $b['score'] <=> $a['score'] ?: $a['id'] <=> $b['id']);
    return array_slice($out, 0, 20);
}
function dsSnapshot($id, $lock = false) {
    $snap = kiSnapshot($id, $lock);
    $snap['data']['structure'] = kiQuery('SELECT record_type,parent_id,unit_label,unit_order,notes FROM katalog_structure WHERE id_naskah=?' . ($lock ? ' FOR UPDATE' : ''), [$id])->get_result()->fetch_assoc() ?: null;
    $snap['data']['identifiers'] = kiQuery('SELECT scheme,identifier_value,source_label,is_primary FROM katalog_identifiers WHERE id_naskah=? ORDER BY id' . ($lock ? ' FOR UPDATE' : ''), [$id])->get_result()->fetch_all(MYSQLI_ASSOC);
    $snap['data']['location_history'] = kiQuery('SELECT location_kind,place_name,district,province,country,period_label,certainty,source_text,sort_order FROM katalog_location_history WHERE id_naskah=? ORDER BY sort_order,id' . ($lock ? ' FOR UPDATE' : ''), [$id])->get_result()->fetch_all(MYSQLI_ASSOC);
    $snap['revision'] = hash('sha256', kiJson($snap['data']));
    return $snap;
}
function dsValidId($value, $table, $column) {
    $value = filter_var($value, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    if (!$value || !kiQuery("SELECT $column FROM $table WHERE $column=?", [$value])->get_result()->fetch_assoc()) throw new InvalidArgumentException('Pilihan ' . $table . ' tidak ditemukan di Kandaga.');
    return $value;
}
function dsApprove($input) {
    global $conn;
    $id = filter_var($input['row_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    $action = (string)($input['action'] ?? '');
    if (!$id || !in_array($action, ['created', 'merged', 'rejected', 'deferred'], true)) throw new InvalidArgumentException('Keputusan moderasi tidak valid.');
    if (!is_string($input['note'] ?? '') || mb_strlen($input['note']) > 4000) throw new InvalidArgumentException('Catatan maksimal 4.000 karakter.');
    if (!dsReady()) throw new InvalidArgumentException('Jalankan migrations/005_catalog_import.sql, migrations/013_catalog_structure_stage1.sql, dan migrations/018_web_import_batch_separation.sql pada database aplikasi dahulu.');
    $conn->begin_transaction();
    try {
        $row = kiRow($id, true, KI_ENGINE_WEB);
        if (!in_array($row['status'], ['pending', 'deferred'], true)) throw new InvalidArgumentException('Baris ini sudah diputuskan. Muat ulang antrean.');
        $oldHistory = $row['draft']['location_history'] ?? [];
        $history = kiLocationHistory($input, $oldHistory, dsSourceLabel($row['draft']['source']));
        if (in_array($action, ['rejected', 'deferred'], true)) {
            if ($history !== $oldHistory) {
                $draft = $row['draft'];
                $draft['location_history'] = $history;
                kiQuery('UPDATE katalog_import_rows SET draft_json=? WHERE id=?', [kiJson($draft), $row['id']]);
                $row['draft'] = $draft;
            }
            kiAudit($row, $action, null, ['location_history' => $oldHistory], ['location_history' => $history], $input);
            $conn->commit();
            return ['id' => null, 'action' => $action];
        }
        $fields = $input['fields'] ?? null;
        $relations = $input['relations'] ?? [];
        $choices = $input['choices'] ?? [];
        if (!is_array($fields) || !is_array($relations) || !is_array($choices)) throw new InvalidArgumentException('Format form moderasi tidak valid.');
        $editable = ['judul', 'kode_inventaris', 'deskripsi_fisik', 'deskripsi_isi', 'riwayat_naskah', 'kata_kunci', 'penyedia_akses', 'url_web', 'url_repositori', 'iiif_manifest', 'url_pdf', 'url_gambar_eksternal'];
        $textFields = ['deskripsi_fisik', 'deskripsi_isi', 'riwayat_naskah'];
        $target = null;
        $before = null;
        $old = null;
        if ($action === 'merged') {
            $target = filter_var($input['target_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
            if (!$target) throw new InvalidArgumentException('Pilih entri tujuan merge.');
            $snapshot = dsSnapshot($target, true);
            $old = $snapshot['data'];
            $before = $old;
            if (!is_string($input['revision'] ?? null) || !hash_equals($snapshot['revision'], $input['revision'])) throw new InvalidArgumentException('Entri tujuan berubah sejak pratinjau. Muat ulang dan periksa kembali.');
        }
        $linked = kiLinked($row['source_key']);
        if ($action === 'created' && $linked) throw new InvalidArgumentException('Identitas sumber ini sudah ditautkan ke entri #' . (int)$linked['katalog_id'] . '. Pilih entri tersebut sebagai tujuan merge.');
        if ($action === 'merged' && $linked && (int)$linked['katalog_id'] !== $target) throw new InvalidArgumentException('Identitas sumber ini sudah ditautkan ke entri #' . (int)$linked['katalog_id'] . '. Gunakan entri tersebut sebagai tujuan merge.');
        $duplicate = kiQuery('SELECT i.id_naskah FROM katalog_identifiers i WHERE i.scheme=? AND i.identifier_value=? LIMIT 1', [$row['draft']['source']['primary']['scheme'], $row['draft']['source']['primary']['value']])->get_result()->fetch_assoc();
        if ($duplicate && $action === 'created' && ($input['duplicate_confirmed'] ?? false) !== true) throw new InvalidArgumentException('Identitas sumber ini sudah tersimpan pada entri #' . (int)$duplicate['id_naskah'] . '. Periksa dan konfirmasikan bila ini memang naskah berbeda.');
        $resolved = [];
        foreach ($editable as $field) {
            if (!is_string($fields[$field] ?? null)) throw new InvalidArgumentException('Field ' . $field . ' tidak valid.');
            $new = trim($fields[$field]);
            $text = in_array($field, $textFields, true);
            $mode = $action === 'created' ? 'use' : ($choices[$field] ?? 'keep');
            if (!in_array($mode, ['keep', 'use', 'append'], true) || ($mode === 'append' && !$text)) throw new InvalidArgumentException('Pilihan merge tidak valid: ' . $field . '.');
            $oldValue = (string)($old['fields'][$field] ?? '');
            if ($mode === 'keep' && trim(strip_tags($oldValue)) !== '') {
                $resolved[$field] = $oldValue;
            } else {
                $max = in_array($field, ['judul', 'kode_inventaris', 'kata_kunci', 'penyedia_akses', 'url_web', 'url_repositori', 'iiif_manifest', 'url_pdf', 'url_gambar_eksternal'], true) ? 255 : 50000;
                if (mb_strlen($new) > $max) throw new InvalidArgumentException($field . ' terlalu panjang.');
                if (in_array($field, ['url_web', 'url_repositori', 'iiif_manifest', 'url_pdf', 'url_gambar_eksternal'], true)) $new = kandagaValidateExternalUrl($new, $field);
                if ($mode === 'append') {
                    if ($new === '') throw new InvalidArgumentException('Tidak ada teks untuk digabungkan pada ' . $field . '.');
                    $credit = kiHtml(dsSourceLabel($row['draft']['source']) . '; msid ' . (string)($row['draft']['source']['msid'] ?? '') . '.');
                    $resolved[$field] = $oldValue . '<p><strong>' . $credit . '</strong><br>' . kiHtml($new) . '</p>';
                } else {
                    if ($action === 'merged' && $new === '' && trim(strip_tags($oldValue)) !== '') throw new InvalidArgumentException('Nilai kosong tidak boleh menghapus data lama: ' . $field . '. Pilih pertahankan.');
                    $resolved[$field] = $text ? kiHtml($new) : $new;
                }
            }
            if ($text && strlen($resolved[$field]) > 60000) throw new InvalidArgumentException('Gabungan deskripsi terlalu panjang untuk kolom TEXT.');
        }
        if (trim($resolved['judul']) === '') throw new InvalidArgumentException('Judul wajib diisi.');
        $locationList = ['lokasi' => ['tb_lokasi', 'id_lokasi'], 'bahasa' => ['tb_bahasa', 'id_bahasa'], 'aksara' => ['tb_aksara', 'id_aksara'], 'alas_tulis' => ['tb_alas_tulis', 'id_alas_tulis']];
        $relationList = ['bahasa' => ['naskah_bahasa', 'id_bahasa'], 'aksara' => ['naskah_aksara', 'id_aksara'], 'alas_tulis' => ['naskah_alas_tulis', 'id_alas_tulis']];
        $locationMode = $action === 'created' ? 'use' : ($choices['id_lokasi'] ?? 'keep');
        if (!in_array($locationMode, ['keep', 'use'], true)) throw new InvalidArgumentException('Pilihan lokasi tidak valid.');
        if ($locationMode === 'keep') {
            $location = (int)($old['fields']['id_lokasi'] ?? 0);
            if (!$location) throw new InvalidArgumentException('Entri tujuan belum memiliki lokasi. Pilih lokasi dari draf.');
        } else {
            $location = dsValidId($input['id_lokasi'] ?? null, 'tb_lokasi', 'id_lokasi');
            if (($input['location_confirmed'] ?? false) !== true) throw new InvalidArgumentException('Konfirmasikan lokasi penyimpanan saat ini; koleksi historis tidak otomatis menjadi lokasi sekarang.');
        }
        if (($input['metadata_confirmed'] ?? false) !== true) throw new InvalidArgumentException('Periksa dan konfirmasikan padanan metadata sebelum menyimpan keputusan.');
        $finalRelations = [];
        foreach (['bahasa', 'aksara', 'alas_tulis'] as $group) {
            $values = $relations[$group] ?? [];
            if (!is_array($values)) throw new InvalidArgumentException('Pilihan relasi tidak valid.');
            $mode = $action === 'created' ? 'replace' : ($choices[$group] ?? 'keep');
            if (!in_array($mode, ['keep', 'union', 'replace'], true)) throw new InvalidArgumentException('Pilihan relasi tidak valid: ' . $group . '.');
            $valid = [];
            if ($mode !== 'keep') foreach ($values as $value) $valid[] = dsValidId($value, $locationList[$group][0], $locationList[$group][1]);
            $oldIds = array_map('intval', (array)($old['relations'][$group] ?? []));
            if ($mode === 'keep') $finalRelations[$group] = array_values(array_unique($oldIds));
            elseif ($mode === 'union') $finalRelations[$group] = array_values(array_unique(array_merge($oldIds, $valid)));
            else {
                if (!$valid && $oldIds) throw new InvalidArgumentException('Pilihan kosong tidak boleh menghapus relasi lama: ' . $group . '.');
                $finalRelations[$group] = array_values(array_unique($valid));
            }
        }
        $bibliografi = [];
        foreach ((array)($input['bibliografi'] ?? []) as $value) $bibliografi[] = dsValidId($value, 'tb_bibliografi', 'id');
        kiEncoding($resolved);
        if ($action === 'created') {
            kiQuery("INSERT INTO katalog(tanggal_input,penginput_awal,judul,id_lokasi,kode_inventaris,deskripsi_fisik,deskripsi_isi,riwayat_naskah,kata_kunci,penyedia_akses,gambar,url_web,url_repositori,iiif_manifest,url_pdf,url_gambar_eksternal) VALUES(NOW(),?,?,?,?,?,?,?,?,?,'',?,?,?,?,?)", [$_SESSION['username'], $resolved['judul'], $location, $resolved['kode_inventaris'], $resolved['deskripsi_fisik'], $resolved['deskripsi_isi'], $resolved['riwayat_naskah'], $resolved['kata_kunci'], $resolved['penyedia_akses'], $resolved['url_web'], $resolved['url_repositori'], $resolved['iiif_manifest'], $resolved['url_pdf'], $resolved['url_gambar_eksternal']]);
            $target = $conn->insert_id;
        } else {
            kiQuery('UPDATE katalog SET judul=?,id_lokasi=?,kode_inventaris=?,deskripsi_fisik=?,deskripsi_isi=?,riwayat_naskah=?,kata_kunci=?,penyedia_akses=?,url_web=?,url_repositori=?,iiif_manifest=?,url_pdf=?,url_gambar_eksternal=?,penyunting_terakhir=?,tanggal_update=NOW() WHERE id=?', [$resolved['judul'], $location, $resolved['kode_inventaris'], $resolved['deskripsi_fisik'], $resolved['deskripsi_isi'], $resolved['riwayat_naskah'], $resolved['kata_kunci'], $resolved['penyedia_akses'], $resolved['url_web'], $resolved['url_repositori'], $resolved['iiif_manifest'], $resolved['url_pdf'], $resolved['url_gambar_eksternal'], $_SESSION['username'], $target]);
        }
        foreach ($finalRelations as $group => $ids) {
            [$table, $column] = $relationList[$group];
            kiQuery("DELETE FROM $table WHERE id_naskah=?", [$target]);
            foreach ($ids as $value) kiQuery("INSERT INTO $table(id_naskah,$column) VALUES(?,?)", [$target, $value]);
        }
        foreach ($bibliografi as $value) if (!kiQuery('SELECT id FROM naskah_bibliografi WHERE id_naskah=? AND id_bibliografi=?', [$target, $value])->get_result()->fetch_assoc()) kiQuery('INSERT INTO naskah_bibliografi(id_naskah,id_bibliografi) VALUES(?,?)', [$target, $value]);
        $structure = $row['draft']['structure'];
        $parent = null;
        $parentMsid = trim((string)$structure['parent_msid']);
        if ($parentMsid !== '') {
            if (preg_match('/^\d{1,6}$/', $parentMsid)) $parentMsid = 'MS' . str_pad($parentMsid, 6, '0', STR_PAD_LEFT);
            $parent = kiQuery('SELECT i.id_naskah FROM katalog_identifiers i WHERE i.scheme=? AND i.identifier_value=? LIMIT 1', ['dreamsea-msid', $parentMsid])->get_result()->fetch_assoc();
            $parent = $parent ? (int)$parent['id_naskah'] : null;
        }
        if ($action === 'created' || !kiQuery('SELECT id_naskah FROM katalog_structure WHERE id_naskah=?', [$target])->get_result()->fetch_assoc()) {
            kiQuery('INSERT INTO katalog_structure(id_naskah,parent_id,record_type,unit_label,unit_order,notes) VALUES(?,?,?,?,?,?)', [$target, $parent, $structure['record_type'], $structure['unit_label'], $structure['unit_order'], $structure['notes']]);
        } else {
            kiQuery('UPDATE katalog_structure SET parent_id=?,record_type=?,unit_label=?,unit_order=?,notes=? WHERE id_naskah=?', [$parent, $structure['record_type'], $structure['unit_label'], $structure['unit_order'], $structure['notes'], $target]);
        }
        foreach ($row['draft']['identifiers'] as $item) kiQuery('INSERT IGNORE INTO katalog_identifiers(id_naskah,scheme,identifier_value,source_label,is_primary) VALUES(?,?,?,?,?)', [$target, $item['scheme'], $item['value'], $item['source'], $item['primary'] ? 1 : 0]);
        // Riwayat lokasi dari sumber ditulis saat entri baru dibuat. Pada merge,
        // hanya ditambahkan bila entri tujuan belum punya riwayat lokasi sama sekali.
        $writeHistory = $action === 'created' || !kiQuery('SELECT id_naskah FROM katalog_location_history WHERE id_naskah=?', [$target])->get_result()->fetch_assoc();
        if ($writeHistory) foreach ($history as $item) kiQuery('INSERT INTO katalog_location_history(id_naskah,location_kind,place_name,district,province,country,period_label,certainty,source_text,sort_order) VALUES(?,?,?,?,?,?,?,?,?,?)', [$target, $item['kind'], $item['place'], $item['district'], $item['province'], $item['country'], $item['period'], $item['certainty'], $item['source'], $item['sort_order']]);
        if (!kiQuery('SELECT source_key FROM katalog_import_sources WHERE source_key=?', [$row['source_key']])->get_result()->fetch_assoc()) kiQuery('INSERT INTO katalog_import_sources(source_key,katalog_id,import_row_id) VALUES(?,?,?)', [$row['source_key'], $target, $row['id']]);
        $after = dsSnapshot($target)['data'];
        kiAudit($row, $action, $target, $before, $after, $input);
        logAktivitas($conn, $action === 'created' ? 'input' : 'edit', ($action === 'created' ? 'Input naskah dari web: ' : 'Edit naskah dari web: ') . $resolved['judul'], $target);
        $conn->commit();
        return ['id' => $target, 'action' => $action];
    } catch (Throwable $e) {
        $conn->rollback();
        throw $e;
    }
}
