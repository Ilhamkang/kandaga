<?php
header("Location: /");
exit();
